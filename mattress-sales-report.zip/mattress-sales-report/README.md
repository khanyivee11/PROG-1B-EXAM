# Mattress Sales Report

A Java 17 example project containing both parts of the assignment:

- A three-month sales report using a one-dimensional product-name array and a two-dimensional monthly-sales array.
- A Swing sales-entry GUI that calculates VAT (15%), commission (5%), and total sale amount, then displays the result and appends it to data.txt.
- JUnit 5 unit tests for the required report and calculation methods.

## Requirements

Install Java 17 or later and Apache Maven.

## Run the sales report (Q1)

From this folder, run:

    mvn compile
    java -cp target/classes com.localcompany.mattress.SalesReportDemo

## Run the GUI (Q2)

From this folder, run:

    mvn compile
    java -cp target/classes com.localcompany.mattress.MattressSalesApp

When a sale is processed, data.txt is created or appended in the application's current working directory. The GUI has no download button, web server, or download endpoint.

## Run the unit tests

    mvn test

## Project files

- IProduct.java and Product.java: sales-report interface and calculations.
- PrintProduct.java and SalesReportDemo.java: report output and sample arrays.
- IProductCalculations.java and ProductCalculations.java: GUI sale calculations.
- MattressSalesApp.java: Swing form, menu actions, result message, and data.txt output.
- src/test/java: the unit tests.

The sample monthly sales in SalesReportDemo are example values; replace them with the company's actual figures when available.
