package com.localcompany.mattress;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class ProductCalculationsTest {
    @Test void GetVat_WithValidData_ReturnsCorrectValue() {
        assertEquals(1500.00, new ProductCalculations(10000.00).GetVat(), 0.001);
    }
    @Test void GetTotal_WithValidData_ReturnsCorrectValue() {
        assertEquals(12000.00, new ProductCalculations(10000.00).GetTotal(), 0.001);
    }
    @Test void GetCommission_WithValidData_ReturnsCorrectValue() {
        assertEquals(500.00, new ProductCalculations(10000.00).GetCommission(), 0.001);
    }
}
