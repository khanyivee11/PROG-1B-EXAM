package com.localcompany.mattress;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

class ProductTest {
    private Product createSampleReport() {
        String[] names = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        int[][] sales = {{12, 15, 18}, {10, 20, 25}, {14, 12, 16}};
        return new Product(names, sales);
    }
    @Test void GetTotalProductSales_WithValidData_ReturnsCorrectValue() {
        assertEquals(142, createSampleReport().GetTotalProductsSold());
    }
    @Test void GetAverageSales_WithValidData_ReturnsCorrectValue() {
        assertEquals(142.0 / 3.0, createSampleReport().GetAverageProductSold(), 0.0001);
    }
    @Test void GetMostPopularProduct_WithValidData_ReturnsCorrectProduct() {
        assertEquals("Restonic Barbados", createSampleReport().GetMostPopularProduct());
    }
    @Test void Constructor_CopiesInputArrays() {
        String[] names = {"Cozy Nights Monarch"};
        int[][] sales = {{3, 4, 5}};
        Product product = new Product(names, sales);
        names[0] = "Changed";
        sales[0][0] = 100;
        assertEquals(12, product.GetTotalProductsSold());
        assertTrue(product.GetMostPopularProduct().equals("Cozy Nights Monarch"));
    }
}
