package com.localcompany.mattress;

import java.util.Arrays;
import java.util.Objects;

/** Calculates summary values from monthly sales for each product. */
public class Product implements IProduct {
    private final String[] productNames;
    private final int[][] monthlySales;

    /** @param productNames one name for each row of monthlySales
     *  @param monthlySales one row per product and one column per month */
    public Product(String[] productNames, int[][] monthlySales) {
        Objects.requireNonNull(productNames, "Product names cannot be null.");
        Objects.requireNonNull(monthlySales, "Monthly sales cannot be null.");
        if (productNames.length == 0 || productNames.length != monthlySales.length) {
            throw new IllegalArgumentException("Provide a product name and sales row for every product.");
        }
        this.productNames = Arrays.copyOf(productNames, productNames.length);
        this.monthlySales = new int[monthlySales.length][];
        int monthCount = -1;
        for (int productIndex = 0; productIndex < monthlySales.length; productIndex++) {
            int[] row = Objects.requireNonNull(monthlySales[productIndex], "Sales rows cannot be null.");
            if (row.length == 0) throw new IllegalArgumentException("Each product must have at least one month's sales.");
            if (monthCount == -1) monthCount = row.length;
            else if (row.length != monthCount) throw new IllegalArgumentException("Every product must have the same number of months.");
            if (this.productNames[productIndex] == null || this.productNames[productIndex].isBlank()) {
                throw new IllegalArgumentException("Product names cannot be blank.");
            }
            for (int sales : row) if (sales < 0) throw new IllegalArgumentException("Sales counts cannot be negative.");
            this.monthlySales[productIndex] = Arrays.copyOf(row, row.length);
        }
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int[] productSales : monthlySales) for (int monthlyTotal : productSales) total = Math.addExact(total, monthlyTotal);
        return total;
    }

    /** Returns the average total sold per product across all supplied months. */
    @Override
    public double GetAverageProductSold() {
        return (double) GetTotalProductsSold() / productNames.length;
    }

    /** Returns the product with the largest combined sales across all months. */
    @Override
    public String GetMostPopularProduct() {
        int bestIndex = 0;
        int bestTotal = -1;
        for (int productIndex = 0; productIndex < monthlySales.length; productIndex++) {
            int productTotal = 0;
            for (int monthlyTotal : monthlySales[productIndex]) productTotal = Math.addExact(productTotal, monthlyTotal);
            if (productTotal > bestTotal) { bestTotal = productTotal; bestIndex = productIndex; }
        }
        return productNames[bestIndex];
    }
}
