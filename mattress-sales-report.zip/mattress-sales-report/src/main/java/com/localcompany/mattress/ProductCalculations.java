package com.localcompany.mattress;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Calculates VAT, commission, and the full sale amount from a product price. */
public class ProductCalculations implements IProductCalculations {
    private static final BigDecimal VAT_RATE = new BigDecimal("0.15");
    private static final BigDecimal COMMISSION_RATE = new BigDecimal("0.05");
    private static final int MONEY_SCALE = 2;
    private final BigDecimal productPrice;

    public ProductCalculations(double productPrice) {
        if (!Double.isFinite(productPrice) || productPrice < 0) {
            throw new IllegalArgumentException("Product price must be a finite, non-negative amount.");
        }
        this.productPrice = BigDecimal.valueOf(productPrice).setScale(MONEY_SCALE, RoundingMode.HALF_UP);
    }
    private BigDecimal calculate(BigDecimal rate) {
        return productPrice.multiply(rate).setScale(MONEY_SCALE, RoundingMode.HALF_UP);
    }
    @Override public double GetVat() { return calculate(VAT_RATE).doubleValue(); }
    @Override public double GetCommission() { return calculate(COMMISSION_RATE).doubleValue(); }
    @Override public double GetTotal() {
        return productPrice.add(calculate(VAT_RATE)).add(calculate(COMMISSION_RATE))
            .setScale(MONEY_SCALE, RoundingMode.HALF_UP).doubleValue();
    }
}
