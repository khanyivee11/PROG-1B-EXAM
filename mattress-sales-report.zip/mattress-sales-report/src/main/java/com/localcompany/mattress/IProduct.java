package com.localcompany.mattress;

/** Operations provided by the three-month product sales report. */
public interface IProduct {
    int GetTotalProductsSold();
    double GetAverageProductSold();
    String GetMostPopularProduct();
}
