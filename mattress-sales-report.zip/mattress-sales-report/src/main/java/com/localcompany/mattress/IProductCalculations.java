package com.localcompany.mattress;

/** Provides the required sales amount calculations for one product. */
public interface IProductCalculations {
    double GetVat();
    double GetCommission();
    double GetTotal();
}
