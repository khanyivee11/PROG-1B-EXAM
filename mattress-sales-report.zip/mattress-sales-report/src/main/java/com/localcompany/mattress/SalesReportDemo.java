package com.localcompany.mattress;

/** Demonstrates the report with sample sales for three products over three months. */
public final class SalesReportDemo {
    private SalesReportDemo() { }
    public static void main(String[] args) {
        // One-dimensional array: one product name per row in monthlySales.
        String[] productNames = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        // Two-dimensional array: rows are products; columns are January, February, March.
        int[][] monthlySales = {{12, 15, 18}, {10, 20, 25}, {14, 12, 16}};
        Product report = new Product(productNames, monthlySales);
        new PrintProduct(report).PrintReport();
    }
}
