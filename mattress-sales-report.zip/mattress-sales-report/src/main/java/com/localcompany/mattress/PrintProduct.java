package com.localcompany.mattress;

/** Prints each required sales-report result. */
public class PrintProduct {
    private final IProduct productReport;
    public PrintProduct(IProduct productReport) {
        if (productReport == null) throw new IllegalArgumentException("A product report is required.");
        this.productReport = productReport;
    }
    public void PrintTotalProductSales() {
        System.out.println("Total products sold: " + productReport.GetTotalProductsSold());
    }
    public void PrintAverageProductSales() {
        System.out.printf("Average products sold per product: %.2f%n", productReport.GetAverageProductSold());
    }
    public void PrintMostPopularProductSale() {
        System.out.println("Most popular product: " + productReport.GetMostPopularProduct());
    }
    public void PrintReport() {
        System.out.println("=== Mattress Sales Report (Three Months) ===");
        PrintTotalProductSales();
        PrintAverageProductSales();
        PrintMostPopularProductSale();
    }
}
