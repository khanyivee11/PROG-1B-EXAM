package com.localcompany.mattress;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/** Swing form for entering a mattress sale, calculating it, and recording it locally. */
public final class MattressSalesApp extends JFrame {
    private static final String[] PRODUCTS = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
    private static final DateTimeFormatter TIMESTAMP_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private final JTextField customerNameField = new JTextField(24);
    private final JComboBox<String> productComboBox = new JComboBox<>(PRODUCTS);
    private final JTextField productPriceField = new JTextField(24);
    private final JTextArea resultArea = new JTextArea(8, 42);
    private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-ZA"));

    private MattressSalesApp() {
        super("Mattress Sales Manager");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setJMenuBar(createMenuBar());
        setContentPane(createContent());
        pack();
        setMinimumSize(new Dimension(560, 470));
        setLocationRelativeTo(null);
    }

    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(event -> dispose());
        fileMenu.add(exitItem);
        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        processItem.addActionListener(event -> processSale());
        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(event -> clearForm());
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);
        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        return menuBar;
    }

    private JPanel createContent() {
        JPanel content = new JPanel(new BorderLayout(12, 12));
        content.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Sale details"));
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(8, 8, 8, 8);
        constraints.anchor = GridBagConstraints.WEST;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        addFormRow(form, constraints, 0, "Customer Name:", customerNameField);
        addFormRow(form, constraints, 1, "Product Name:", productComboBox);
        addFormRow(form, constraints, 2, "Product Price (R):", productPriceField);
        JButton processButton = new JButton("Process");
        processButton.addActionListener(event -> processSale());
        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(event -> clearForm());
        JPanel buttons = new JPanel();
        buttons.add(processButton);
        buttons.add(clearButton);
        resultArea.setEditable(false);
        resultArea.setLineWrap(true);
        resultArea.setWrapStyleWord(true);
        resultArea.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        JScrollPane resultScroll = new JScrollPane(resultArea);
        resultScroll.setBorder(BorderFactory.createTitledBorder("Most recent processed sale"));
        content.add(form, BorderLayout.NORTH);
        content.add(resultScroll, BorderLayout.CENTER);
        content.add(buttons, BorderLayout.SOUTH);
        return content;
    }

    private static void addFormRow(JPanel panel, GridBagConstraints constraints, int row, String label, java.awt.Component input) {
        constraints.gridy = row;
        constraints.gridx = 0;
        constraints.weightx = 0;
        panel.add(new JLabel(label), constraints);
        constraints.gridx = 1;
        constraints.weightx = 1;
        panel.add(input, constraints);
    }

    private void processSale() {
        String customerName = customerNameField.getText().trim();
        if (customerName.isEmpty()) {
            showError("Enter the customer's name.");
            customerNameField.requestFocusInWindow();
            return;
        }
        final BigDecimal price;
        try {
            String rawPrice = productPriceField.getText().trim().replace(",", "");
            price = new BigDecimal(rawPrice);
            if (price.signum() <= 0) {
                showError("Enter a product price greater than zero.");
                productPriceField.requestFocusInWindow();
                return;
            }
        } catch (NumberFormatException exception) {
            showError("Enter a valid numeric product price, for example 12999.99.");
            productPriceField.requestFocusInWindow();
            return;
        }
        ProductCalculations calculations = new ProductCalculations(price.doubleValue());
        String productName = (String) productComboBox.getSelectedItem();
        String report = createSaleReport(customerName, productName, price, calculations);
        try {
            appendSaleToFile(customerName, productName, price, calculations);
        } catch (IOException exception) {
            showError("The sale could not be saved to data.txt. Check that the application folder is writable.\n" + exception.getMessage());
            return;
        }
        resultArea.setText(report);
        JOptionPane.showMessageDialog(this, report + "\n\nSaved to data.txt.", "Sale Processed", JOptionPane.INFORMATION_MESSAGE);
    }

    private String createSaleReport(String customerName, String productName, BigDecimal price, IProductCalculations calculations) {
        return "Customer Name: " + customerName
            + "\nProduct Name: " + productName
            + "\nProduct Price: " + formatCurrency(price.doubleValue())
            + "\nVAT Amount (15%): " + formatCurrency(calculations.GetVat())
            + "\nCommission Amount (5%): " + formatCurrency(calculations.GetCommission())
            + "\nTotal Sale Amount: " + formatCurrency(calculations.GetTotal());
    }

    private void appendSaleToFile(String customerName, String productName, BigDecimal price, IProductCalculations calculations) throws IOException {
        String safeCustomerName = customerName.replace("\r", " ").replace("\n", " ");
        String safeProductName = productName == null ? "" : productName.replace("\r", " ").replace("\n", " ");
        String entry = "Timestamp: " + LocalDateTime.now().format(TIMESTAMP_FORMAT)
            + "\nCustomer Name: " + safeCustomerName
            + "\nProduct Name: " + safeProductName
            + "\nProduct Price: " + formatCurrency(price.doubleValue())
            + "\nVAT Amount (15%): " + formatCurrency(calculations.GetVat())
            + "\nCommission Amount (5%): " + formatCurrency(calculations.GetCommission())
            + "\nTotal Sale Amount: " + formatCurrency(calculations.GetTotal())
            + "\n----------------------------------------\n";
        java.nio.file.Files.writeString(java.nio.file.Path.of("data.txt"), entry,
            java.nio.charset.StandardCharsets.UTF_8,
            java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
    }

    private String formatCurrency(double amount) { return currencyFormat.format(amount); }
    private void clearForm() {
        customerNameField.setText("");
        productPriceField.setText("");
        productComboBox.setSelectedIndex(0);
        resultArea.setText("");
        customerNameField.requestFocusInWindow();
    }
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Input or File Error", JOptionPane.ERROR_MESSAGE);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MattressSalesApp().setVisible(true));
    }
}
